import { setPlaceholders } from './placeholders.js';

setPlaceholders();

$('#opcionesCodigoOrdenTrabajo > a').on('click', setDropdownValue); 

function setDropdownValue() {
    let $option = $(this);
    // Buscamos el input donde establecer el valor de la opcion seleccionada
    $option.closest('.input-group').find('input').val($option.text());
}








var almacenFull = document.createElement("div"); //ALmacen donde se encuentran todos los datos del popover
var almacenTotal = document.createElement("div"); //Almacen total de datos
almacenTotal.id = "almacenFormulario";
var add; //Boton añadir
var enviar; //Botón DONE
var almacenBoton; // Almacen donde irá el botón añadir y DONE
var almacenDatos = []; 
var almacenEliminar; //Almacen donde se encontrará el botón para eliminar las tarjetas
var valor = 0; //Contador global


crearFormulario(); //Creamos el formulario

almacenFull.appendChild(almacenTotal);

crearBoton(); //Creamos el apartado donde irá el botón de añadir tarjetas y el DONE


add.addEventListener("click", crearFormulario); //Cada vez que clickemos el botón de añadir, creamos un nuevo apartado de formulario
enviar.addEventListener("click", recogerDatos); //Cuando clickemos el botón "DONE" guardamos sus datos en una variable
document.getElementById("buscador").addEventListener("click", mostrarDatos); //Cuando clickemos el botón "Buscar" mostraremos los datos por consola

/**
 * Creamos el formulario del popover
 */
function crearFormulario() {
    var almacenPrueba;
    var temp = document.getElementsByTagName("template")[0]; //Cogemos el template
    var clon = temp.content.cloneNode(true); //Clonamos el template
    var almacenTarjeta = document.createElement("div"); //Almacen individual para cada tarjeta
    almacenEliminar = document.createElement("div"); //ALmacen donde se añadirá la "X" para eliminar tarjetas
    almacenEliminar.id = "almacenEliminar";
    
    


    if (valor == 0) {
        almacenPrueba = document.createTextNode('1 Habitación');
    }
    else {
        almacenPrueba = document.createTextNode(``);
        crearEliminacion(almacenTarjeta);
    }

    almacenFull.id = "almacenFull";

    //Aquí guardamos la tarjeta
    almacenTarjeta.id = "tarjeta";
    almacenTarjeta.appendChild(almacenEliminar); // X (eliminar)
    almacenTarjeta.appendChild(almacenPrueba); // Id Habitaciones
    almacenTarjeta.appendChild(clon); //Formulario


    almacenTotal.appendChild(almacenTarjeta);//Almacen de todos los formularios
    //ALmacen de formularios y boton de añadir

    
    if (valor > 0) { //Comrprobamos que el valor de la ID no sea 0 para empezar a añadir las id de habitaciones
        crearID();
    }
    valor++;
    
}


/**
 * Creamos el boton de añadir tarjetas y terminar 
 */
function crearBoton() {
    almacenBoton = document.createElement("div"); //Almacen donde estará el botón de añadir y el DONE

    add = document.createElement("button");
    enviar = document.createElement("button");

    var plus = document.createTextNode("+");
    var done = document.createTextNode("DONE");

    almacenBoton.id = "addHabitaciones";
    add.id = "botonAdd";

    add.appendChild(plus);
    enviar.appendChild(done);
    almacenBoton.appendChild(add);
    almacenBoton.appendChild(enviar);
    almacenFull.appendChild(almacenBoton); //Añadimos el botón de añadir tarjetas y el DONE a su contenedor
}




//Creamos el botón eliminar para eliminar tarjetas de formulario y eliminamos la tarjeta en caso de que pulse el campo "X"
function crearEliminacion(almacenTarjeta) {

    var botonEliminar; //Boton eliminar
    botonEliminar = document.createElement("button");
    var cross = document.createTextNode("X");

    botonEliminar.appendChild(cross);
    botonEliminar.id = valor;

    almacenEliminar.appendChild(botonEliminar);
    almacenTarjeta.appendChild(almacenEliminar);

    botonEliminar.addEventListener("click", function () { //Eliminamos la tarjeta
        botonEliminar.parentElement.parentElement.remove();
        crearID();
    });
}



//Creamos el id de cada habitación
function crearID() {

    var almacenTarjetas = almacenFull.childNodes[0].childNodes;
    for (var acct = 1; acct <= almacenTarjetas.length; acct++) {//Recorremos las tarjetas aplicándole el id a cada una
        almacenTarjetas[acct].childNodes[1].textContent = acct + 1 + " Habitación";
    }
}



//Recogemos los datos y los guardamos en un array de objetos para mostrarlos posteriormente
function recogerDatos() {

    $("[data-toggle='popover']").popover('hide'); //Ocultamos el popover
    
    if (almacenDatos[0] != null) { //Comprobamos si el almacen está vacío, si no, eliminamos su contenido
        almacenDatos.splice(0, almacenDatos.length);
    }
    var almacenTarjetas = almacenFull.childNodes[0].childNodes; //Nos situamos en el contenedor de cada tarjeta
    for (var acct = 0; acct <= almacenTarjetas.length; acct++) {//Recorremos tarjeta por tarjeta 
        var adultos = almacenTarjetas[acct].childNodes[3].childNodes[1].childNodes[1].childNodes[3].value;//Adultos
        var ninios = almacenTarjetas[acct].childNodes[3].childNodes[1].childNodes[3].childNodes[3].value; //Niños
        var datosTarjeta = {
            adultos: adultos,
            ninio: ninios
        };
        almacenDatos.push(datosTarjeta);
    }

}


/**
 * Mostramos los datos por consola
 */
function mostrarDatos() {
    console.clear();
    var acct = 1;
    console.log('RESERVA HOTELERA');
    console.log('Destino: ' + document.getElementById("destino").value);
    console.log('Fecha de entrada: ' + document.getElementById("date").value);
    console.log('Número de noches: ' + document.getElementById("noches").value);
    almacenDatos.forEach(function (value) {
        console.log('\tEn la habitación ' + acct + ' se hospedarán:')
        console.log('\t\tAdultos: ', value.adultos);
        console.log('\t\tNiños: ', value.ninio);
        acct++;
    });
}



$('[data-toggle="popover"]').popover({
    html: true,
    content: almacenFull
});