
function setPlaceholders(){
    destino();
    date();
    noches();
    habitaciones();
    
}



function destino(){
    var contText = document.getElementById("destino");
    contText.placeholder = "Hotel o destino";
}

function date(){
    var contDate = document.getElementById("date");
    var f = new Date();
    var horaCanarias = f.getFullYear() + "-" + ("0" + f.getMonth()+2).slice(-2) + "-" +("0" + f.getDate()).slice(-2);
    contDate.value = horaCanarias;
    contDate.setAttribute("min", horaCanarias);
}

function noches(){
    var contText = document.getElementById("noches");
    contText.placeholder = "0 Noches";
}

function habitaciones(){
    var contText = document.getElementById("today");
    contText.placeholder = "0 hab & 0 pers.";
}
export{setPlaceholders}